package com.example.captainneuro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
